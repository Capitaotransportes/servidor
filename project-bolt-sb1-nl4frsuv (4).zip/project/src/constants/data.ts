import { ServiceType, DifferentialType, TestimonialType } from '../types';
import { Truck, Clock, Map, Users, ShieldCheck, Zap, Award, PhoneCall } from 'lucide-react';

export const navLinks = [
  { name: 'Início', href: '#home' },
  { name: 'Sobre', href: '#about' },
  { name: 'Serviços', href: '#services' },
  { name: 'Diferenciais', href: '#differentials' },
  { name: 'Contato', href: '#contact' },
];

export const services: ServiceType[] = [
  {
    id: 1,
    title: 'Transporte de Motos para Todo o Brasil',
    description: 'Transporte especializado para motocicletas em qualquer cidade ou estado do país, com total segurança e cuidado personalizado.',
    icon: 'Truck',
  },
  {
    id: 2,
    title: 'Socorro e Remoção Emergencial',
    description: 'Atendimento emergencial para sua moto em caso de problemas ou imprevistos na estrada, com transporte imediato até o local desejado.',
    icon: 'Clock',
  },
  {
    id: 3,
    title: 'Transporte para Oficinas',
    description: 'Serviço de leva e traz para oficinas mecânicas, ideal para quando você não pode levar sua moto pessoalmente.',
    icon: 'Map',
  },
  {
    id: 4,
    title: 'Apoio Logístico para Viagens',
    description: 'Transporte da sua motocicleta para o destino da viagem, evitando desgaste e quilometragem desnecessária.',
    icon: 'Users',
  },
];

export const differentials: DifferentialType[] = [
  {
    id: 1,
    title: 'Rapidez e Pontualidade',
    description: 'Trabalhamos com prazos reduzidos e entrega dentro do combinado, porque sabemos da importância da sua moto.',
    icon: 'Zap',
  },
  {
    id: 2,
    title: 'Preço Justo e Transparência',
    description: 'Serviço de alta qualidade com valores acessíveis e sem surpresas no orçamento.',
    icon: 'Award',
  },
  {
    id: 3,
    title: 'Segurança Total',
    description: 'Veículos equipados e sistemas de fixação de alta qualidade para evitar qualquer dano no transporte.',
    icon: 'ShieldCheck',
  },
  {
    id: 4,
    title: 'Atendimento Personalizado',
    description: 'Suporte completo durante todo o processo de transporte, com comunicação clara e eficiente.',
    icon: 'PhoneCall',
  },
];

export const testimonials: TestimonialType[] = [
  {
    id: 1,
    name: 'Ricardo Almeida',
    role: 'Cliente São Paulo - SP',
    content: 'Precisei transportar minha moto para outro estado e o serviço foi excelente! Entrega no prazo e minha moto chegou em perfeitas condições.',
  },
  {
    id: 2,
    name: 'Amanda Souza',
    role: 'Cliente Rio de Janeiro - RJ',
    content: 'Ótimo serviço de remoção emergencial. Rápidos, profissionais e preço justo. Recomendo!',
  },
  {
    id: 3,
    name: 'Carlos Mendes',
    role: 'Cliente Curitiba - PR',
    content: 'Transportaram minha moto nova da concessionária até minha casa com todo cuidado. Serviço de primeira qualidade.',
  },
];

export const getIconComponent = (iconName: string) => {
  switch (iconName) {
    case 'Truck':
      return Truck;
    case 'Clock':
      return Clock;
    case 'Map':
      return Map;
    case 'Users':
      return Users;
    case 'ShieldCheck':
      return ShieldCheck;
    case 'Zap':
      return Zap;
    case 'Award':
      return Award;
    case 'PhoneCall':
      return PhoneCall;
    default:
      return Truck;
  }
};