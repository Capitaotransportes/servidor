import React, { useRef } from 'react';
import { differentials } from '../constants/data';
import { getIconComponent } from '../constants/data';
import { useInView } from '../hooks/useInView';

const Differentials: React.FC = () => {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { threshold: 0.1 });
  
  return (
    <section id="differentials" className="py-20 bg-navy-900 text-white">
      <div className="container">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="section-title text-white text-center mx-auto after:left-1/2 after:-translate-x-1/2 after:bg-red-600">
            Nossos Diferenciais
          </h2>
          <p className="text-gray-300">
            Descubra porque somos a escolha número um para o transporte e assistência 
            de veículos de alto valor.
          </p>
        </div>
        
        <div 
          ref={ref}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8"
        >
          {differentials.map((item, index) => {
            const IconComponent = getIconComponent(item.icon);
            
            return (
              <div 
                key={item.id}
                className={`bg-navy-800 rounded-lg p-6 transition-all duration-700 transform ${
                  isInView 
                    ? 'opacity-100 translate-y-0' 
                    : 'opacity-0 translate-y-10'
                }`}
                style={{ transitionDelay: `${index * 100}ms` }}
              >
                <div className="mb-4 text-red-600">
                  <IconComponent size={36} />
                </div>
                <h3 className="text-xl font-semibold mb-3">{item.title}</h3>
                <p className="text-gray-300">{item.description}</p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default Differentials;