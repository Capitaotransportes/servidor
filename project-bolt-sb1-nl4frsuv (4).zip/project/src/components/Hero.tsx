import React, { useEffect, useState } from 'react';
import { ChevronDown } from 'lucide-react';

const Hero: React.FC = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    setIsVisible(true);
  }, []);
  
  return (
    <section 
      id="home" 
      className="relative h-screen flex items-center bg-hero-pattern bg-cover bg-center"
    >
      <div className="absolute inset-0 bg-gradient-to-b from-navy-900/60 to-navy-900/90"></div>
      
      <div 
        className={`container relative z-10 text-white transition-all duration-1000 transform ${
          isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
        }`}
      >
        <div className="max-w-3xl">
          <h2 className="text-xl md:text-2xl uppercase tracking-wider mb-3 text-gray-metal font-semibold">
            Capitão Transportes
          </h2>
          <h1 className="text-3xl md:text-5xl lg:text-6xl font-bold mb-6 leading-tight">
            Precisa transportar sua moto com segurança, rapidez e um preço justo?
          </h1>
          <p className="text-lg md:text-xl mb-8 text-gray-200 max-w-2xl">
            A Capitão Transportes é a solução ideal! Especializados no transporte de motocicletas, atendemos todo o Brasil, garantindo um serviço confiável para quem precisa mover sua moto sem preocupações.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <a 
              href="#contact" 
              className="btn-primary"
            >
              Solicite um Orçamento Agora!
            </a>
            <a 
              href="#services" 
              className="inline-flex items-center justify-center px-6 py-3 border border-white text-base font-medium rounded-md text-white hover:bg-white hover:text-navy-900 transition-all duration-300"
            >
              Nossos Serviços
            </a>
          </div>
        </div>
      </div>
      
      <a 
        href="#about" 
        className="absolute bottom-8 left-1/2 transform -translate-x-1/2 text-white animate-bounce"
        aria-label="Rolar para baixo"
      >
        <ChevronDown size={36} />
      </a>
    </section>
  );
};

export default Hero;