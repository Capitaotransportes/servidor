import React from 'react';
import { Mail, Phone, MapPin, Facebook, Instagram, Linkedin } from 'lucide-react';

const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="bg-navy-900 text-white pt-16 pb-8">
      <div className="container">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
          <div>
            <div className="flex items-center mb-6">
              <img 
                src="https://i.ibb.co/RGCKqZcq/Whats-App-Image-2025-05-01-at-15-36-04.jpg" 
                alt="Capitão Transportes Logo" 
                className="h-16 w-auto object-contain rounded-lg"
              />
            </div>
            <p className="text-gray-300 mb-6">
              Especialistas em transporte e assistência emergencial para veículos de alto valor e performance.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-300 hover:text-white transition-colors">
                <Facebook size={20} />
              </a>
              <a href="#" className="text-gray-300 hover:text-white transition-colors">
                <Instagram size={20} />
              </a>
              <a href="#" className="text-gray-300 hover:text-white transition-colors">
                <Linkedin size={20} />
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-xl font-semibold mb-6 relative after:content-[''] after:absolute after:-bottom-2 after:left-0 after:w-12 after:h-1 after:bg-red-600">
              Navegação
            </h3>
            <ul className="space-y-3">
              <li>
                <a href="#home" className="text-gray-300 hover:text-white transition-colors">Início</a>
              </li>
              <li>
                <a href="#about" className="text-gray-300 hover:text-white transition-colors">Sobre</a>
              </li>
              <li>
                <a href="#services" className="text-gray-300 hover:text-white transition-colors">Serviços</a>
              </li>
              <li>
                <a href="#differentials" className="text-gray-300 hover:text-white transition-colors">Diferenciais</a>
              </li>
              <li>
                <a href="#contact" className="text-gray-300 hover:text-white transition-colors">Contato</a>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-xl font-semibold mb-6 relative after:content-[''] after:absolute after:-bottom-2 after:left-0 after:w-12 after:h-1 after:bg-red-600">
              Serviços
            </h3>
            <ul className="space-y-3">
              <li className="text-gray-300">Transporte de Motos de Luxo</li>
              <li className="text-gray-300">Resgate Emergencial 24h</li>
              <li className="text-gray-300">Transporte de Quadriciclos</li>
              <li className="text-gray-300">Assistência a Comboios</li>
              <li className="text-gray-300">Entregas de Longa Distância</li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-xl font-semibold mb-6 relative after:content-[''] after:absolute after:-bottom-2 after:left-0 after:w-12 after:h-1 after:bg-red-600">
              Contato
            </h3>
            <ul className="space-y-4">
              <li className="flex items-start">
                <Phone size={20} className="mr-3 text-gray-metal flex-shrink-0 mt-1" />
                <span className="text-gray-300">(11) 99999-9999</span>
              </li>
              <li className="flex items-start">
                <Mail size={20} className="mr-3 text-gray-metal flex-shrink-0 mt-1" />
                <span className="text-gray-300">contato@capitaotransportes.com.br</span>
              </li>
              <li className="flex items-start">
                <MapPin size={20} className="mr-3 text-gray-metal flex-shrink-0 mt-1" />
                <span className="text-gray-300">
                  Av. Paulista, 1000 - Bela Vista<br />
                  São Paulo - SP, 01310-100
                </span>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-navy-800 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-sm">
              &copy; {currentYear} Capitão Transportes. Todos os direitos reservados.
            </p>
            <p className="text-gray-400 text-sm mt-2 md:mt-0">
              Desenvolvido com <span className="text-red-600">❤</span> por Bolt
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;