import React, { useEffect, useRef } from 'react';
import { useInView } from '../hooks/useInView';

const About: React.FC = () => {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { threshold: 0.3 });
  
  return (
    <section id="about" className="py-20 bg-gray-light">
      <div className="container">
        <div 
          ref={ref}
          className={`grid md:grid-cols-2 gap-12 items-center transition-all duration-1000 ${
            isInView ? 'opacity-100 transform-none' : 'opacity-0 translate-y-10'
          }`}
        >
          <div>
            <h2 className="section-title">Por que escolher a Capitão Transportes?</h2>
            <p className="text-navy-800 mb-6">
              Seja para levar sua moto até uma oficina, atender emergências, oferecer suporte em viagens ou transportar para qualquer estado do país, nós estamos prontos para atender com qualidade e eficiência.
            </p>
            <ul className="space-y-4 text-navy-800">
              <li className="flex items-start">
                <span className="text-green-600 mr-2">✅</span>
                <span>Transporte para Todo o Brasil – Levamos sua moto para qualquer cidade ou estado do país com total segurança.</span>
              </li>
              <li className="flex items-start">
                <span className="text-green-600 mr-2">✅</span>
                <span>Emergências e Resgates – Se sua moto apresentou problemas ou sofreu um imprevisto na estrada, nós realizamos o transporte imediato até o local desejado.</span>
              </li>
              <li className="flex items-start">
                <span className="text-green-600 mr-2">✅</span>
                <span>Segurança Total – Utilizamos veículos equipados e sistemas de fixação de alta qualidade para evitar qualquer dano no transporte.</span>
              </li>
            </ul>
          </div>
          
          <div className="relative h-96 rounded-lg overflow-hidden shadow-xl">
            <img 
              src="https://images.pexels.com/photos/1119796/pexels-photo-1119796.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" 
              alt="Equipe Capitão Transportes" 
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-b from-navy-900/60 to-navy-900/90"></div>
            <div className="absolute bottom-0 left-0 right-0 p-6">
              <span className="bg-navy-600 text-white px-4 py-2 rounded-full text-sm font-semibold">
                Sua Moto Vai Longe, com Segurança e Confiança!
              </span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;