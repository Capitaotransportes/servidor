export interface ServiceType {
  id: number;
  title: string;
  description: string;
  icon: string;
}

export interface DifferentialType {
  id: number;
  title: string;
  description: string;
  icon: string;
}

export interface TestimonialType {
  id: number;
  name: string;
  role: string;
  content: string;
  avatar?: string;
}